﻿using System;
using UnityEngine.Events;

[Serializable]
public class QuestConfigAndEventProvider
{
    public QuestConfig QuestConfig;
    public UnityEvent OnClaim;
}