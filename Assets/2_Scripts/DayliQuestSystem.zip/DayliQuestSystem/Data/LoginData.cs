using System;

[Serializable]
public class LoginData
{
    public DateTime DateTime;

    public int DayCount;
}
