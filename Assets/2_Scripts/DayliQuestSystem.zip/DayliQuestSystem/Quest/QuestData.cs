﻿using System;

[Serializable]
public class QuestData
{
    public int Progress;
    public bool IsClaimed;
}