public enum QuestType 
{
    Kill15Enemy,
    PassSecondLevel,
    PumpWall3Times,
    UpgradeOneWeapon,
    PlayTheGameFor10Minutes,
    KillOneBoss,
    Earn300Coins,
    TakeTheDailyReward,
    FindOneWeapon,
    WinTheGameWithoutLosingALife,
}
